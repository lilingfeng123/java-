package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.onedao;
import entity.Adm;
import entity.Shop;

public class one extends HttpServlet {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("gbk");
		response.setCharacterEncoding("gbk");
		String flag=request.getParameter("flag");
		if("login".equals(flag)){
			Adm adm=new Adm();
			adm.setAdminID(request.getParameter("AdminID"));
			adm.setPassword(request.getParameter("Password"));
			boolean bl=new onedao().login(adm);
			if(bl){
				request.getSession().setAttribute("AdminID", adm.getAdminID());
				request.getRequestDispatcher("loginsuccess.jsp").forward(request, response);
			}else{
				request.getSession().setAttribute("new", "登录失败");
				request.getRequestDispatcher("login.jsp").forward(request, response);
			}
		}else if("selectshop".equals(flag)){
			ArrayList<Shop> al=new onedao().selectshop();
			request.setAttribute("al", al);
			request.getRequestDispatcher("selectshop.jsp").forward(request, response);
		}else if("myshopcar".equals(flag)){
			String[] shops=request.getParameterValues("myshop");
			ArrayList<String> al=new ArrayList<String>();
			if(shops!=null){
				for(String str:shops){
					al.add(str);
				}
			}
			request.setAttribute("al", al);
			request.getRequestDispatcher("myshopcar.jsp").forward(request, response);
		}
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("gbk");
		response.setCharacterEncoding("gbk");
		this.doGet(request, response);
	}

}
